package UserAuth;

import Constant.AppsConstant;
import Before.LoginApi;
import Constant.RequestSpec;
import Constant.TestProvider;
import Constant.Utils;
import Model.UserAuthModel;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

//@Listeners(TestAnalyzeReportListener.class)
public class UserAuth extends RequestSpec {


    UserAuthModel model = new UserAuthModel();
    String token ="";
    String RESETPIN;



    /*
    Creating JSONobject to send a parameter
    Validating response by providing CONTENT_TYPE & Fetching token from api response and storing in Variable.
     */
   // @Test(priority = 1)

     @Test(priority = 1, retryAnalyzer = Constant.TestAnalyser.class , dataProvider ="dataprovider",dataProviderClass = TestProvider.class)
     @BeforeTest
     void login(String username,String password){
         System.out.println(username+" and "+ password);
         LoginApi loginApi = new LoginApi();
         model = loginApi.callLoginApi(username,password);
         token = model.getToken();
         System.out.println("login"+token);
     }
    /*
     Passing the Query param
     */
    @Test(priority = 2)
    void logoutApi() {
        String type ="WebApp";
        System.out.println("hu" + token);

        RequestSpec requestSpec = new RequestSpec();

        given()
                .queryParam("source" ,type)
                .spec(requestSpec.setup(token))
                .when()
                .put(AppsConstant.USERS_LOGUT)
                .then()
                .statusCode(200);
    }

    /*
         Fetching Resetpin from the api response and storing in var.
     */

    @Test(priority = 3)
    void forgotPassword(){

        final JSONObject reqJson = new JSONObject();
        reqJson.put("emailId", "ayushi@yopmail.com");

        ValidatableResponse response=  given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(reqJson.toString())
                .when()
                .post(AppsConstant.USER_FORGOTPASSWORD)
                .then()
                .statusCode(200);

        RESETPIN = response.extract().body().jsonPath().get("data.resetPin").toString();
        model.setResetpin(RESETPIN);

    }
    /*
      This Api is used for reset the user password with the help of ResetPin.
     */

    @Test(priority = 4)
    void resetPassword(){

        final JSONObject reqJson = new JSONObject();
        reqJson.put("resetKey", model.getResetpin(RESETPIN));
        reqJson.put("password", Utils.PASSWORD);

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(reqJson.toString())
                .when()
                .put(AppsConstant.USERS_RESETPASSWORD)
                .then()
                .statusCode(200)
                .body("message", equalTo("Your password has been changed"));


    }
}
