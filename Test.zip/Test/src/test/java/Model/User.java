package Model;

import java.lang.reflect.Array;

public class User{
  private String fullname;
    private String gender;
    private boolean enableTracking;
    private boolean smsNotification;
    private int relativeImportance;
    private String roleCode;
    private String numberOfProjectsAllowed;
    private String numberOfUsersAllowed;
    private String zoneSubDetailsDtos;
    private String caseManagerType;
    private int accessToWhatsapp;
    private String preferredLanguage;
    private String phoneCountryCode;
    private String phone;
    private String selfRegistered;
    private String emailId;
    private String registeredFrom;
    private int enableIVR;
    private String checkInCode;
    private String password;

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isEnableTracking() {
        return enableTracking;
    }

    public void setEnableTracking(boolean enableTracking) {
        this.enableTracking = enableTracking;
    }

    public boolean isSmsNotification() {
        return smsNotification;
    }

    public void setSmsNotification(boolean smsNotification) {
        this.smsNotification = smsNotification;
    }

    public int getRelativeImportance() {
        return relativeImportance;
    }

    public void setRelativeImportance(int relativeImportance) {
        this.relativeImportance = relativeImportance;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getNumberOfProjectsAllowed() {
        return numberOfProjectsAllowed;
    }

    public void setNumberOfProjectsAllowed(String numberOfProjectsAllowed) {
        this.numberOfProjectsAllowed = numberOfProjectsAllowed;
    }

    public String getNumberOfUsersAllowed() {
        return numberOfUsersAllowed;
    }

    public void setNumberOfUsersAllowed(String numberOfUsersAllowed) {
        this.numberOfUsersAllowed = numberOfUsersAllowed;
    }

    public String getZoneSubDetailsDtos() {
        return zoneSubDetailsDtos;
    }

    public void setZoneSubDetailsDtos(String zoneSubDetailsDtos) {
        this.zoneSubDetailsDtos = zoneSubDetailsDtos;
    }

    public String getCaseManagerType() {
        return caseManagerType;
    }

    public void setCaseManagerType(String caseManagerType) {
        this.caseManagerType = caseManagerType;
    }

    public int getAccessToWhatsapp() {
        return accessToWhatsapp;
    }

    public void setAccessToWhatsapp(int accessToWhatsapp) {
        this.accessToWhatsapp = accessToWhatsapp;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    public String getPhoneCountryCode() {
        return phoneCountryCode;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSelfRegistered() {
        return selfRegistered;
    }

    public void setSelfRegistered(String selfRegistered) {
        this.selfRegistered = selfRegistered;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmaiId(String emailId) {
        this.emailId = emailId;
    }

    public String getRegisteredFrom() {
        return registeredFrom;
    }

    public void setRegisteredFrom(String registeredFrom) {
        this.registeredFrom = registeredFrom;
    }

    public int getEnableIVR() {
        return enableIVR;
    }

    public void setEnableIVR(int enableIVR) {
        this.enableIVR = enableIVR;
    }

    public String getCheckInCode() {
        return checkInCode;
    }

    public void setCheckInCode(String checkInCode) {
        this.checkInCode = checkInCode;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}


