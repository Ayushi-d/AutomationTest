package Model;

public class UserAuthModel {

    public UserAuthModel() {
    }

    private String token;
    private String resetpin;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getResetpin(String RESETPIN) {
        return resetpin;
    }

    public void setResetpin(String resetpin) {
        this.resetpin = resetpin;
    }
}
