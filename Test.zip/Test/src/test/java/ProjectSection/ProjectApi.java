package ProjectSection;

import Before.LoginApi;
import Constant.AppsConstant;
import Constant.RequestSpec;
import Constant.Utils;
import Model.UserAuthModel;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Random;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.requestSpecification;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.equalTo;

public class ProjectApi {

    UserAuthModel userAuthModel = new UserAuthModel();
    String token ="";


    @Test(priority = 1,retryAnalyzer = Constant.TestAnalyser.class)
    @BeforeTest
    void login(){
        LoginApi loginApi = new LoginApi();
        userAuthModel = loginApi.callLoginApi("admin@techfrolic.com","123456");
        token = userAuthModel.getToken();
        System.out.println("login"+token);
    }

    @Test(priority = 2,retryAnalyzer = Constant.TestAnalyser.class)
    void createProject() {
        System.out.println("this"+token);
        final JSONObject reqJson = new JSONObject();
        reqJson.put("projectName", generateRandomPassword(1));
        reqJson.put("projectCity", "Indore");
        reqJson.put("projectDescription", "test");

        RequestSpec spec = new RequestSpec();

        given()
                .spec(spec.setup(token))
                .header(AppsConstant.CONTENT_TYPE ,"application/json")
                .body(reqJson.toString())
                .when()
                .post(AppsConstant.CREATEPROJECT)
                .then()
                .statusCode(SC_OK);
                //.body("data.emailId", equalTo(EMAIL));

    }

    @Test(priority = 3,retryAnalyzer = Constant.TestAnalyser.class)
    void getAllProject() {

        given()
                .header(AppsConstant.AUTH_HEADER_NAME ,"Bearer "+ token)
                .when()
                .get(AppsConstant.GETALLPROJECT)
                .then()
                .statusCode(200);
    }


        public String generateRandomPassword(int len) {
            String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk"
                    +"lmnopqrstuvwxyz!@#$%&";
            Random rnd = new Random();
            StringBuilder sb = new StringBuilder(len);
            for (int i = 0; i < len; i++)
                sb.append(chars.charAt(rnd.nextInt(chars.length())));
            return sb.toString();
        }

}
