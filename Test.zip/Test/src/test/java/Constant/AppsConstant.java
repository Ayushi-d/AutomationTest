package Constant;

public class AppsConstant {

    public static String BASE_URL = "http://13.244.158.216:9091/pulse/v1";
    public static String USERS_ENDPOINT = BASE_URL + "/public-api/users/";

    //In User Auth
    public static String USERS_LOGIN = BASE_URL + "/auth/login";
    //public static String USERS_LOGIN = BASE_URL + "/auth/logi";
    public static String USERS_LOGUT = BASE_URL + "/auth/logou?soruce=WebApp";
   // public static String USERS_LOGUT = BASE_URL + "/auth/logout?soruce=WebApp";
    public static String USER_FORGOTPASSWORD = BASE_URL + "/forgetpassword";
    public static String USERS_RESETPASSWORD = BASE_URL + "/resetpassword";

    //In user section


    public static String USERS_CREATE = BASE_URL + "/users";
    public static String GETUSER = BASE_URL + "/users/";
    public static String UPDATEUSER = BASE_URL + "/users/";
    public static String DELETEUSER = BASE_URL + "/users/";

    //In projet section
    public static String CREATEPROJECT = BASE_URL + "/projects";
    public static String GETALLPROJECT = BASE_URL + "/projects";

    public static String AUTH_HEADER_NAME = "Authorization";
    public static String CONTENT_TYPE = "Content-Type";

}
