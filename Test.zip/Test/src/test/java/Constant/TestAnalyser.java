package Constant;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import org.testng.annotations.Test;

public class TestAnalyser implements IRetryAnalyzer {
    int callLimit= 0;
    int totalCount= 4;

    @Override
    public boolean retry(ITestResult iTestResult) {
      if(callLimit<totalCount){
          callLimit++;
          return true;
      }
        return false;
    }
}

