package Constant;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.util.logging.LogRecord;

public class RestAssureFilter implements Filter {
    Response response;
    private final static Logger logger = LogManager.getLogger(RestAssureFilter.class);

    @Override
    public Response filter(FilterableRequestSpecification filterableRequestSpecification, FilterableResponseSpecification
            filterableResponseSpecification, FilterContext filterContext) {
        response = filterContext.next(filterableRequestSpecification,filterableResponseSpecification);
        if (response.statusCode()!=200){
            logger.error(filterableRequestSpecification.getMethod() + " "+filterableRequestSpecification.getURI() + " "+
                    response.getStatusCode() + " "+ response.getStatusLine());
        }
        System.out.println("I am calling you");
        logger.info(filterableRequestSpecification.getMethod() + " "+filterableRequestSpecification.getURI() + " "+
                response.getStatusCode() + " "+ response.getStatusLine());
        return response;
    }
}
