package Constant;

import io.restassured.RestAssured;

public  class ApiToken {

    public static String getToken() {
        return RestAssured
                .get("http://13.244.158.216:9091/pulse/v1/auth")
                .jsonPath()
                .get("token");
    }
}
