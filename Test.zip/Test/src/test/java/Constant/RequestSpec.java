package Constant;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class RequestSpec {

    public  RequestSpecification requestSpecification;

    public RequestSpecification setup(String Token){

        RequestSpecBuilder requestSpecBuild = new RequestSpecBuilder();
        requestSpecBuild
                .setContentType(ContentType.JSON)
                .setAccept(ContentType.JSON)
                .addHeader(AppsConstant.AUTH_HEADER_NAME,"Bearer " + Token);

        requestSpecification = requestSpecBuild.build();
        return requestSpecification;

    }

}
