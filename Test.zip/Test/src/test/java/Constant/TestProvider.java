package Constant;

import org.testng.annotations.DataProvider;

public class TestProvider {

    @DataProvider(name = "dataprovider")
    public String[][] provider(){

        return new String[][]{
                {
                        "ayushi@yopmail.com ",
                        "ayushi"
                }
        };
    }
}
