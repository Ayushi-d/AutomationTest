package Constant;

public class Utils {

    public static  String EMAIL = "ayushi@yopmail.com";
    public static String PASSWORD = "ayushi";
    public static long Phonenum = 7696140781L;
    public static String TOKEN;
}
