package UserSection;

import Before.LoginApi;
import Constant.AppsConstant;
import Constant.Global;
import Constant.RequestSpec;
import Model.User;
import Model.UserAuthModel;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.restassured.response.ValidatableResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Random;

import static io.restassured.RestAssured.given;
import static org.apache.http.HttpStatus.SC_OK;

public class UserApi {

    UserAuthModel model = new UserAuthModel();
    String token ="";
    String userID ="";

    @Test(priority = 1,retryAnalyzer = Constant.TestAnalyser.class )
    @Story("login")
    @Description("This is login api")
    @BeforeTest
    void login(){
        LoginApi loginApi = new LoginApi();
        model = loginApi.callLoginApi("ayushi@yopmail.com","ayushi");
        token = model.getToken();
        System.out.println(token);
    }

    @Test(priority = 2,retryAnalyzer = Constant.TestAnalyser.class)
    @Story("createUser")
    @Description("This is createUser api")
    void createUser() {

        final JSONObject reqJson = new JSONObject();
        //Created array bracket[]
        JSONArray array = new JSONArray();
        //Created json array obj {} eg: [{}]
        JSONObject arrayobj = new JSONObject();
        //adding array obj key value
        arrayobj.put("name","delta");
        arrayobj.put("id",4130);
        //bind arrayobj into array
        array.put(arrayobj);

        reqJson.put("fullname", Global.generateRandomname(7));
        reqJson.put("gender", "F");
        reqJson.put("enableTracking", true);
        reqJson.put("smsNotification", true);
        reqJson.put("relativeImportance", 5);
        reqJson.put("roleCode", "ROLE_PREMIUM_USER");
        reqJson.put("numberOfProjectsAllowed", "");
        reqJson.put("numberOfUsersAllowed", "");
        reqJson.put("zoneSubDetailsDtos",array);
        reqJson.put("caseManagerType", "");
        reqJson.put("accessToWhatsapp", true);
        reqJson.put("preferredLanguage", "English");
        reqJson.put("phoneCountryCode", "+91");
        reqJson.put("phone", Global.generateRandom(10));
        reqJson.put("selfRegistered", "false");
        reqJson.put("emailid", "null");
        reqJson.put("registeredFrom", "WebApp");
        reqJson.put("enableIVR", true);
        reqJson.put("checkInCode", 3);

        System.out.println(reqJson.toString());

        RequestSpec spec = new RequestSpec();

        ValidatableResponse response= given()
                .spec(spec.setup(token))
                .header(AppsConstant.CONTENT_TYPE ,"application/json")
                .body(reqJson.toString())
                .when()
                .post(AppsConstant.USERS_CREATE)
                .then()
                .log().ifError()
                .statusCode(SC_OK);

        userID = response.extract().body().jsonPath().get("data.userId").toString();
        System.out.println(userID);

    }

    @Test(priority = 3,retryAnalyzer = Constant.TestAnalyser.class)
    @Story("getUserById")
    @Description("This is getUserById api")
    void getUserById() {

        given()
                .header(AppsConstant.AUTH_HEADER_NAME ,"Bearer "+ token)
                .when()
                .get(AppsConstant.GETUSER+userID)
                .then()
                .statusCode(200);
    }
    @Test(priority = 4,retryAnalyzer = Constant.TestAnalyser.class)
    @Story("getuUpdateUser")
    @Description("This is getuUpdateUser api")
    void getuUpdateUser() {

        final JSONObject reqJson = new JSONObject();
        JSONArray array = new JSONArray();
        JSONObject arrayobj = new JSONObject();
        arrayobj.put("id",749);
        arrayobj.put("name","gombe");
        array.put(arrayobj);

        reqJson.put("userId", userID);
        reqJson.put("fullname", Global.generateRandomname(6));
        reqJson.put("gender", "F");
        reqJson.put("enableTracking", false);
        reqJson.put("smsNotification", false);
        reqJson.put("relativeImportance", 5);
        reqJson.put("roleCode", "ROLE_CASE_MANAGER");
        reqJson.put("numberOfProjectsAllowed", "");
        reqJson.put("numberOfUsersAllowed", "");
        reqJson.put("zoneSubDetailsDtos", array);
        reqJson.put("caseManagerType", "Police");
        reqJson.put("accessToWhatsapp", false);
        reqJson.put("preferredLanguage", "English");
        reqJson.put("phoneCountryCode", +234);
        reqJson.put("phone", Global.generateRandom(10));
        reqJson.put("selfRegistered", false);
        reqJson.put("emailid", "ayushi@yopmail.com");
        reqJson.put("registeredFrom", "WebApp");
        reqJson.put("enableIVR", false);
        reqJson.put("checkInCode", 0);

        RequestSpec spec = new RequestSpec();

        given()
                .spec(spec.setup(token))
                .header(AppsConstant.CONTENT_TYPE ,"application/json")
                .body(reqJson.toString())
                .when()
                .put(AppsConstant.UPDATEUSER+userID)
                .then().statusCode(200);

               /* .then()
                .statusCode(200);*/
    }


    @Test(priority =5,retryAnalyzer = Constant.TestAnalyser.class)
    @Story("getDeleteUser")
    @Description("This is getDeleteUser api")
    void getDeleteUser() {

        given()
                .header(AppsConstant.AUTH_HEADER_NAME ,"Bearer "+ token)
                .when()
                .delete(AppsConstant.DELETEUSER+userID)
                .then()
                .statusCode(200);
    }
}
