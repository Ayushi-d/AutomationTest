package Test;

import Constant.ApiToken;
import Constant.AppsConstant;
import bsh.org.objectweb.asm.Constants;
import io.restassured.http.ContentType;
import org.json.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.equalTo;


public class PostApi {

    private final String NAME = "Osanda Nimalarathna";
    private final String EMAIL = "osanda2@gmail.com";
    private final String GENDER = "male";
    private final String STATUS = "active";
    private String USER_ID;

    @Test()
    public void postApiCall() {
        final JSONObject reqJson = new JSONObject();
        reqJson.put("name", NAME);
        reqJson.put("email", EMAIL);
        reqJson.put("gender", GENDER);
        reqJson.put("status", STATUS);

        /* .setContentType(ContentType.JSON)
                .setAccept(ContentType.JSON)
                .addHeader(Constants.AUTH_HEADER_NAME, "Bearer " + Token.getToken());
        */
         given()
                 .contentType(ContentType.JSON)
                 .accept(ContentType.JSON)
                 .header(AppsConstant.AUTH_HEADER_NAME, "Bearer " + ApiToken.getToken())
               /*.spec(requestSpecification)*/
                .body(reqJson.toString())
                .when()
                .post(AppsConstant.USERS_ENDPOINT)
                .then()
                .statusCode(SC_OK)
                .body("data.name", equalTo(NAME));
          /*      .body("data.email", equalTo(EMAIL))
                .body("data.gender", equalTo(GENDER))
                .body("data.status", equalTo(STATUS));*/
    }

    @Test
    void apiCallTwo(){
        JSONObject request = new JSONObject();
        request.put("name", "chaya");
        request.put("job", "BA");
//key value pair use put
        System.out.println(request);
        System.out.println(request.toString());

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(AppsConstant.AUTH_HEADER_NAME, "Bearer " + ApiToken.getToken())
                .body(request.toString()).
                when().log().all().
                post("https://reqres.in/api/users").
                then().log().all().statusCode(201 ); // log all se we get all info which sent by server
    }

    @Test

    void loginApi(){
        given().
                auth().
                preemptive(). //inputs
                basic("username", "password").
                when().log().all().
                get("http://path.to/basic/secured/api").
                then().
                assertThat().
                statusCode(200);
    }
}
