package Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;


public class GetApiCalling {

    @Test
     void get() {
        Response response = RestAssured.get("https://reqres.in/api/users/2");
        System.out.println(response.getStatusCode());
        System.out.println(response.getBody().asString());  //response obj (use as string to get resp in norml form)
        System.out.println(response.getStatusLine()); //http protocl with status code and status
        int code = response.getStatusCode();
        Assert.assertEquals(code, 200);
    }

    @Test
    void getapi(){
        given()
                .get("https://reqres.in/api/users/2")
                .then()
                .statusCode(200).body("data.first_name",equalTo("Janet"));
    }

    @Test
    void gettypeapi(){
        given().
                when(). // type trigger
                get("https://reqres.in/api/users/2").
                then(). //hold response
                assertThat().     //assert or add validation(expctd or not)
                body("data.first_name",equalTo("Janet"))
                .and().statusCode(200);
    }

    @Test
    void checkqueryparam(){
        String originalText = "test";
        String expectedMd5CheckSum = "098f6bcd4621d373cade4e832627b4f6";


        //http://md5.jsontest.com/?text=test,
        given().
               // param("text",originalText). //can pass multipl
                param("text",originalText).  //text is key param & test is value param
                when().  //when to triggr it
                get("http://md5.jsontest.com").
                then().  //to match
                assertThat().
                body("md5",equalTo(expectedMd5CheckSum));
    }

    @Test
    void checkpathparam(){
        String season = "2017";
        int numberOfRaces = 20;

        given().
                pathParam("raceSeason",season).
                when().
                get("http://ergast.com/api/f1/{raceSeason}/circuits.json").
                then().
                assertThat().
                body("MRData.CircuitTable.Circuits.circuitId",hasSize(numberOfRaces));
    }

    @Test
    void testqueryapi(){
        String num = "9781449325862";
        String url = "https://bookstore.toolsqa.com/BookStore/v1";
        given()
                .queryParam("ISBN",num)
                .when()
                .get(url+"/Book")
                .then()
                .assertThat()
                .body("title",equalTo("Git Pocket Guide"))
                .body("pages",equalTo(234))
                .statusCode(200);
    }


    @Test
    void testpathparam(){

        given()
                .pathParam("id","62710afd5a4555499c82ecc9")
                .when()
                .get("http://93.188.167.68:9090/api/jobs/getJobs/{id}")
                .then()
                .assertThat()
                .statusCode(200)
                .body("message",equalTo("jobs Detail"))
                .body("data.company.emailId",equalTo("abc@abc.com"))
                .body("data.workers",equalTo(10));
    }
}

