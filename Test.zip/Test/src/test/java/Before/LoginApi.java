package Before;

import Constant.AppsConstant;
import Constant.RestAssureFilter;
import Constant.Utils;
import Model.User;
import Model.UserAuthModel;
import io.restassured.response.ValidatableResponse;
import org.json.JSONObject;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.put;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.equalTo;

public class LoginApi extends RestAssureFilter {
    String TOKEN;
    //model
    UserAuthModel model = new UserAuthModel();


    public LoginApi() {
    }

    //setting token in this meathod & and given model type in meathod cause we want to use this in another class as well
    public UserAuthModel callLoginApi(String email, String password) {
       // final JSONObject reqJson = new JSONObject();

        //pojo class
        User user= new User();

        //using pojo class
        user.setEmaiId(email);
        user.setPassword(password);
/*
        reqJson.put("emailId", email);
        reqJson.put("password", password);*/

        ValidatableResponse response = given()
                /* .contentType(ContentType.JSON)
                 .accept(ContentType.JSON)*/
                .filter(new RestAssureFilter())
                .header(AppsConstant.CONTENT_TYPE ,"application/json")
                .body(user)
                .when()
                .post(AppsConstant.USERS_LOGIN)
                .then()
                .statusCode(SC_OK);
               /* .body("data.emailId", equalTo(Utils.EMAIL))
                .body("data.phoneNumber", equalTo(Utils.Phonenum));
*/
        TOKEN = response.extract().body().jsonPath().get("data.token").toString();
        model.setToken(TOKEN);
        return model;

    }


}
